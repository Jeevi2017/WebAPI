using System.ComponentModel.DataAnnotations;

namespace EventManagement.Models
{
    public class SpeakersDetails
    {
        [Key]
        public int SpeakerId { get; set; }

        [Required]
        [StringLength(50, MinimumLength = 1)]
        public string SpeakerName { get; set; }
    }
}
