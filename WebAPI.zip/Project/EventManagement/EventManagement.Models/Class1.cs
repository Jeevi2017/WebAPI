﻿namespace EventManagement.Models;

public class Class1
{

}
