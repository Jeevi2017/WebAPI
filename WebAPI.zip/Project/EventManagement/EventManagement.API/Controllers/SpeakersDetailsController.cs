using Microsoft.AspNetCore.Mvc;
using EventManagement.DAL.Repository;
using EventManagement.Models;

namespace EventManagement.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class SpeakersDetailsController : ControllerBase
    {
        private readonly ISpeakersDetailsRepository _repo;

        public SpeakersDetailsController(ISpeakersDetailsRepository repo)
        {
            _repo = repo;
        }

        [HttpGet]
        public IActionResult GetAll() => Ok(_repo.GetAll());

        [HttpGet("{id}")]
        public IActionResult Get(int id)
        {
            var speaker = _repo.GetById(id);
            if (speaker == null)
                return NotFound("Speaker not found");
            return Ok(speaker);
        }

        [HttpPost]
        public IActionResult Post(SpeakersDetails speaker)
        {
            _repo.Add(speaker);
            return Ok("Speaker Added");
        }

        [HttpPut]
        public IActionResult Put(SpeakersDetails speaker)
        {
            var existingSpeaker = _repo.GetById(speaker.SpeakerId);
            if (existingSpeaker == null)
                return NotFound("Speaker not found");

            _repo.Update(speaker);
            return Ok("Speaker Updated");
        }

        [HttpDelete("{id}")]
        public IActionResult Delete(int id)
        {
            var existingSpeaker = _repo.GetById(id);
            if (existingSpeaker == null)
                return NotFound("Speaker not found");

            _repo.Delete(id);
            return Ok("Speaker Deleted");
        }
    }
}
