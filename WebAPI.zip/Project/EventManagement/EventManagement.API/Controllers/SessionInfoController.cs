using Microsoft.AspNetCore.Mvc;
using EventManagement.DAL.Repository;
using EventManagement.Models;

namespace EventManagement.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class SessionInfoController : ControllerBase
    {
        private readonly ISessionInfoRepository _repo;

        public SessionInfoController(ISessionInfoRepository repo)
        {
            _repo = repo;
        }

        [HttpGet]
        public IActionResult GetAll() => Ok(_repo.GetAll());

        [HttpGet("{id}")]
        public IActionResult Get(int id)
        {
            var session = _repo.GetById(id);
            if (session == null)
                return NotFound("Session not found");
            
            return Ok(session);
        }

        [HttpPost]
        public IActionResult Post([FromBody] SessionInfo session)
        {
            _repo.Add(session);
            return Ok("Session Added");
        }

        [HttpPut]
        public IActionResult Put(SessionInfo session)
        {
            var existingSession = _repo.GetById(session.SessionId);
            if (existingSession == null)
                return NotFound("Session not found");
            
            _repo.Update(session);
            return Ok("Session Updated");
        }

        [HttpDelete("{id}")]
        public IActionResult Delete(int id)
        {
            var existingSession = _repo.GetById(id);
            if (existingSession == null)
                return NotFound("Session not found");

            _repo.Delete(id);
            return Ok("Session Deleted");
        }
    }
}
