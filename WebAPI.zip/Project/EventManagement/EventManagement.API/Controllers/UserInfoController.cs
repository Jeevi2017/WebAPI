using Microsoft.AspNetCore.Mvc;
using EventManagement.DAL.Repository;
using EventManagement.Models;

namespace EventManagement.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class UserInfoController : ControllerBase
    {
        private readonly IUserInfoRepository _repo;

        public UserInfoController(IUserInfoRepository repo)
        {
            _repo = repo;
        }

        [HttpGet]
        public IActionResult GetAll() => Ok(_repo.GetAll());

        [HttpGet("{email}")]
        public IActionResult Get(string email)
        {
            var user = _repo.GetByEmail(email);
            if (user == null)
                return NotFound("User not found");
            return Ok(user);
        }

        [HttpPost]
        public IActionResult Post(UserInfo user)
        {
            _repo.Add(user);
            return Ok("User Added");
        }

        [HttpPut]
        public IActionResult Put(UserInfo user)
        {
            var existingUser = _repo.GetByEmail(user.EmailId);
            if (existingUser == null)
                return NotFound("User not found");

            _repo.Update(user);
            return Ok("User Updated");
        }

        [HttpDelete("{email}")]
        public IActionResult Delete(string email)
        {
            var existingUser = _repo.GetByEmail(email);
            if (existingUser == null)
                return NotFound("User not found");

            _repo.Delete(email);
            return Ok("User Deleted");
        }
    }
}
