using Microsoft.AspNetCore.Mvc;
using EventManagement.DAL.Repository;
using EventManagement.Models;

namespace EventManagement.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class EventDetailsController : ControllerBase
    {
        private readonly IEventDetailsRepository _repo;

        public EventDetailsController(IEventDetailsRepository repo)
        {
            _repo = repo;
        }

        [HttpGet]
        public IActionResult GetAll() => Ok(_repo.GetAll());

        [HttpGet("{id}")]
        public IActionResult Get(int id)
        {
            var eventDetail = _repo.GetById(id);
            if (eventDetail == null)
                return NotFound("Event not found");

            return Ok(eventDetail);
        }

        [HttpPost]
        public IActionResult Post(EventDetails ev)
        {
            _repo.Add(ev);
            return Ok("Event Added");
        }

        [HttpPut]
        public IActionResult Put(EventDetails ev)
        {
            var existingEvent = _repo.GetById(ev.EventId);
            if (existingEvent == null)
                return NotFound("Event not found");

            _repo.Update(ev);
            return Ok("Event Updated");
        }

        [HttpDelete("{id}")]
        public IActionResult Delete(int id)
        {
            var existingEvent = _repo.GetById(id);
            if (existingEvent == null)
                return NotFound("Event not found");

            _repo.Delete(id);
            return Ok("Event Deleted");
        }
    }
}
