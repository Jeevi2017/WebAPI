using Microsoft.AspNetCore.Mvc;
using EventManagement.DAL.Repository;
using EventManagement.Models;

namespace EventManagement.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ParticipantEventDetailsController : ControllerBase
    {
        private readonly IParticipantEventDetailsRepository _repo;

        public ParticipantEventDetailsController(IParticipantEventDetailsRepository repo)
        {
            _repo = repo;
        }

        [HttpGet]
        public IActionResult GetAll() => Ok(_repo.GetAll());

        [HttpGet("{id}")]
        public IActionResult Get(int id)
        {
            var detail = _repo.GetById(id);
            if (detail == null)
                return NotFound("Participant Event Detail not found");
            
            return Ok(detail);
        }

        [HttpPost]
        public IActionResult Post(ParticipantEventDetails detail)
        {
            _repo.Add(detail);
            return Ok("Participant Event Detail Added");
        }

        [HttpPut]
        public IActionResult Put(ParticipantEventDetails detail)
        {
            var existingDetail = _repo.GetById(detail.Id);
            if (existingDetail == null)
                return NotFound("Participant Event Detail not found");

            _repo.Update(detail);
            return Ok("Participant Event Detail Updated");
        }

        [HttpDelete("{id}")]
        public IActionResult Delete(int id)
        {
            var existingDetail = _repo.GetById(id);
            if (existingDetail == null)
                return NotFound("Participant Event Detail not found");

            _repo.Delete(id);
            return Ok("Participant Event Detail Deleted");
        }
    }
}
