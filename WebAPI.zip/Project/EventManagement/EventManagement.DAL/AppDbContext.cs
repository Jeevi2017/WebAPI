using Microsoft.EntityFrameworkCore;
using EventManagement.Models;

namespace EventManagement.DAL
{
    public class AppDbContext : DbContext
    {
        public AppDbContext(DbContextOptions<AppDbContext> options) : base(options) {}

        public DbSet<UserInfo> Users { get; set; }
        public DbSet<EventDetails> Events { get; set; }
        public DbSet<SpeakersDetails> Speakers { get; set; }
        public DbSet<SessionInfo> Sessions { get; set; }
        public DbSet<ParticipantEventDetails> ParticipantEvents { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<UserInfo>()
                .HasKey(u => u.EmailId);

            modelBuilder.Entity<EventDetails>()
                .HasKey(e => e.EventId);

            modelBuilder.Entity<SpeakersDetails>()
                .HasKey(s => s.SpeakerId);

            modelBuilder.Entity<SessionInfo>()
                .HasKey(s => s.SessionId);

            modelBuilder.Entity<SessionInfo>()
                .HasOne<EventDetails>()
                .WithMany()
                .HasForeignKey(s => s.EventId);

            modelBuilder.Entity<SessionInfo>()
                .HasOne<SpeakersDetails>()
                .WithMany()
                .HasForeignKey(s => s.SpeakerId);

            modelBuilder.Entity<ParticipantEventDetails>()
                .HasKey(p => p.Id);

            modelBuilder.Entity<ParticipantEventDetails>()
                .HasOne<UserInfo>()
                .WithMany()
                .HasForeignKey(p => p.ParticipantEmailId);

            modelBuilder.Entity<ParticipantEventDetails>()
                .HasOne<EventDetails>()
                .WithMany()
                .HasForeignKey(p => p.EventId);
        }
    }
}
