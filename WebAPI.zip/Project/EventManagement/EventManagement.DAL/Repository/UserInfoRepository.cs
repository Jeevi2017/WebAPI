using EventManagement.Models;
using System.Collections.Generic;
using System.Linq;

namespace EventManagement.DAL.Repository
{
    public class UserInfoRepository : IUserInfoRepository
    {
        private readonly AppDbContext _context;

        public UserInfoRepository(AppDbContext context)
        {
            _context = context;
        }

        public IEnumerable<UserInfo> GetAll() => _context.Users.ToList();

        public UserInfo GetByEmail(string email) => _context.Users.Find(email);

        public void Add(UserInfo user)
        {
            _context.Users.Add(user);
            _context.SaveChanges();
        }

        public void Update(UserInfo user)
        {
            _context.Users.Update(user);
            _context.SaveChanges();
        }

        public void Delete(string email)
        {
            var user = _context.Users.Find(email);
            if (user != null)
            {
                _context.Users.Remove(user);
                _context.SaveChanges();
            }
        }
    }
}
