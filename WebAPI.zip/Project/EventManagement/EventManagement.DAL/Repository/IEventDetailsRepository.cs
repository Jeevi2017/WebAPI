using EventManagement.Models;
using System.Collections.Generic;

namespace EventManagement.DAL.Repository
{
    public interface IEventDetailsRepository
    {
        IEnumerable<EventDetails> GetAll();
        EventDetails GetById(int id);
        void Add(EventDetails ev);
        void Update(EventDetails ev);
        void Delete(int id);
    }
}
