using EventManagement.Models;
using System.Collections.Generic;
using System.Linq;

namespace EventManagement.DAL.Repository
{
public class SessionInfoRepository : ISessionInfoRepository
{
    private readonly AppDbContext _context;

    public SessionInfoRepository(AppDbContext context)
    {
        _context = context;
    }

    public IEnumerable<SessionInfo> GetAll() => _context.Sessions.ToList();

    public SessionInfo GetById(int id) => _context.Sessions.Find(id);

    public void Add(SessionInfo session)
    {
        _context.Sessions.Add(session);
        _context.SaveChanges();
    }

    public void Update(SessionInfo session)
    {
        _context.Sessions.Update(session);
        _context.SaveChanges();
    }

    public void Delete(int id)
    {
        var session = _context.Sessions.Find(id);
        if (session != null)
        {
            _context.Sessions.Remove(session);
            _context.SaveChanges();
        }
    }
}
}