using EventManagement.Models;
using System.Collections.Generic;

namespace EventManagement.DAL.Repository
{
    public interface IUserInfoRepository
    {
        IEnumerable<UserInfo> GetAll();
        UserInfo GetByEmail(string email);
        void Add(UserInfo user);
        void Update(UserInfo user);
        void Delete(string email);
    }
}
