using EventManagement.Models;
using System.Collections.Generic;

namespace EventManagement.DAL.Repository
{
    public interface IParticipantEventDetailsRepository
    {
        IEnumerable<ParticipantEventDetails> GetAll();
        ParticipantEventDetails GetById(int id);
        void Add(ParticipantEventDetails detail);
        void Update(ParticipantEventDetails detail);
        void Delete(int id);
    }
}