using EventManagement.Models;
using System.Collections.Generic;
using System.Linq;

namespace EventManagement.DAL.Repository
{

    public class ParticipantEventDetailsRepository : IParticipantEventDetailsRepository
    {
        private readonly AppDbContext _context;

        public ParticipantEventDetailsRepository(AppDbContext context)
        {
            _context = context;
        }

        public IEnumerable<ParticipantEventDetails> GetAll() => _context.ParticipantEvents.ToList();

        public ParticipantEventDetails GetById(int id) => _context.ParticipantEvents.Find(id);

        public void Add(ParticipantEventDetails detail)
        {
            _context.ParticipantEvents.Add(detail);
            _context.SaveChanges();
        }

        public void Update(ParticipantEventDetails detail)
        {
            _context.ParticipantEvents.Update(detail);
            _context.SaveChanges();
        }

        public void Delete(int id)
        {
            var detail = _context.ParticipantEvents.Find(id);
            if (detail != null)
            {
                _context.ParticipantEvents.Remove(detail);
                _context.SaveChanges();
            }
        }
    }
}
