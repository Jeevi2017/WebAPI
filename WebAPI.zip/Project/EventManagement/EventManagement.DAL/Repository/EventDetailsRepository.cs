using EventManagement.Models;
using System.Collections.Generic;
using System.Linq;

namespace EventManagement.DAL.Repository
{
    public class EventDetailsRepository : IEventDetailsRepository
    {
        private readonly AppDbContext _context;

        public EventDetailsRepository(AppDbContext context)
        {
            _context = context;
        }

        public IEnumerable<EventDetails> GetAll() => _context.Events.ToList();

        public EventDetails GetById(int id) => _context.Events.Find(id);

        public void Add(EventDetails ev)
        {
            _context.Events.Add(ev);
            _context.SaveChanges();
        }

        public void Update(EventDetails ev)
        {
            _context.Events.Update(ev);
            _context.SaveChanges();
        }

        public void Delete(int id)
        {
            var ev = _context.Events.Find(id);
            if (ev != null)
            {
                _context.Events.Remove(ev);
                _context.SaveChanges();
            }
        }
    }
}
