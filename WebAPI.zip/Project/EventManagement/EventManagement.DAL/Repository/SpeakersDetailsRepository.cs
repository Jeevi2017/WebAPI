using EventManagement.Models;
using System.Collections.Generic;
using System.Linq;

namespace EventManagement.DAL.Repository
{
public class SpeakersDetailsRepository : ISpeakersDetailsRepository
{
    private readonly AppDbContext _context;

    public SpeakersDetailsRepository(AppDbContext context)
    {
        _context = context;
    }

    public IEnumerable<SpeakersDetails> GetAll() => _context.Speakers.ToList();

    public SpeakersDetails GetById(int id) => _context.Speakers.Find(id);

    public void Add(SpeakersDetails speaker)
    {
        _context.Speakers.Add(speaker);
        _context.SaveChanges();
    }

    public void Update(SpeakersDetails speaker)
    {
        _context.Speakers.Update(speaker);
        _context.SaveChanges();
    }

    public void Delete(int id)
    {
        var speaker = _context.Speakers.Find(id);
        if (speaker != null)
        {
            _context.Speakers.Remove(speaker);
            _context.SaveChanges();
        }
    }
}
}