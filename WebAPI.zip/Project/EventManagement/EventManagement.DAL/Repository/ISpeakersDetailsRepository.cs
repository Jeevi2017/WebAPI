using EventManagement.Models;
using System.Collections.Generic;

namespace EventManagement.DAL.Repository
{

    public interface ISpeakersDetailsRepository
    {
        IEnumerable<SpeakersDetails> GetAll();
        SpeakersDetails GetById(int id);
        void Add(SpeakersDetails speaker);
        void Update(SpeakersDetails speaker);
        void Delete(int id);
    }
}
