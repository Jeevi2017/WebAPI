using EventManagement.Models;
using System.Collections.Generic;

namespace EventManagement.DAL.Repository
{
    public interface ISessionInfoRepository
    {
        IEnumerable<SessionInfo> GetAll();
        SessionInfo GetById(int id);
        void Add(SessionInfo session);
        void Update(SessionInfo session);
        void Delete(int id);
    }
}
